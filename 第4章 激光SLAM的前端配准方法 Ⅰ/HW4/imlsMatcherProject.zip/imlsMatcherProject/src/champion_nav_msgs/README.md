### install
安装自定义消息到系统

   `sudo su`

   `source /opt/ros/kinetic/setup.bash`

   `catkin_make -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/opt/ros/kinetic install`
